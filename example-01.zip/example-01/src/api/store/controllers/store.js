'use strict';

/**
 *  store controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::store.store');
