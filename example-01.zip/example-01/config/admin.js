module.exports = ({ env }) => ({
  auth: {
    secret: env('ADMIN_JWT_SECRET', '1b2bc0fa5d93d2861333c79c2a695806'),
  },
});
